<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<h2>User Login</h2>
<form action="/tournaments/user-login-post" method="post">
    <?= csrf_field() ?>
    <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" name="username" class="form-control" required autofocus>
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" name="password" class="form-control" required>
    </div>
    <?php if(session()->getFlashdata('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?= session()->getFlashdata('error') ?>
        </div>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary">Login</button>
</form>
<?= $this->endSection() ?>
