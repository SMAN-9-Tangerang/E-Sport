<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
    <h2>Buat Turnamen Baru</h2>
    <form action="/tournaments/store" method="post">
        <?= csrf_field() ?>
        <div class="mb-3">
            <label for="name" class="form-label">Nama Turnamen</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="game_name" class="form-label">Game</label>
            <input type="text" name="game_name" class="form-control" value="Mobile Legends" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Deskripsi</label>
            <textarea name="description" class="form-control"></textarea>
        </div>
        <div class="mb-3">
            <label for="tournament_type" class="form-label">Tipe Turnamen</label>
            <select name="tournament_type" class="form-select">
                <option value="single elimination">Single Elimination</option>
                <option value="double elimination">Double Elimination</option>
                <option value="round robin">Round Robin</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="start_at" class="form-label">Tanggal Mulai</label>
            <input type="datetime-local" name="start_at" class="form-control" value="<?= date('Y-m-d\TH:i') ?>">
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
<?= $this->endSection() ?>
