<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Team - <?= esc($team['name']) ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <h1>Manage Team: <?= esc($team['name']) ?></h1>

    <h2>Team Members</h2>
    <?php if (empty($members)): ?>
        <p>No members in this team yet.</p>
    <?php else: ?>
        <table border="1" cellpadding="5" cellspacing="0">
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Status</th>
                    <th>Role</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($members as $member): ?>
                <tr>
                    <td><?= esc($member['user_id']) ?></td>
                    <td><?= esc($member['status']) ?></td>
                    <td><?= esc($member['role']) ?></td>
                    <td>
                        <?php if ($member['role'] !== 'leader'): ?>
                        <form action="/tournaments/removeMember/<?= esc($member['id']) ?>" method="post" style="display:inline;">
                            <button type="submit" onclick="return confirm('Are you sure you want to remove this member?');">Remove</button>
                        </form>
                        <?php else: ?>
                        <em>Owner</em>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <h2>Add Member</h2>
    <form action="/tournaments/inviteUserToTeam/<?= esc($team['id']) ?>" method="post">
        <label for="username">Username to invite:</label>
        <input type="text" id="username" name="username" required>
        <button type="submit">Add Member</button>
    </form>

    <p><a href="/tournaments/teams/<?= esc($team['tournament_id']) ?>">Back to Teams</a></p>
</body>
</html>
