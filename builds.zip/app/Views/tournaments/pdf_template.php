<!DOCTYPE html>
<html>
<head>
    <title>Daftar Tim</title>
    <style>
        body { font-family: sans-serif; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h2>Daftar Tim - <?= esc($tournament['name']) ?></h2>
    <table>
        <thead>
            <tr>
                <th>Nama Tim</th>
                <th>Tag</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($teams as $team): ?>
            <tr>
                <td><?= esc($team['name']) ?></td>
                <td><?= esc($team['tag']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>