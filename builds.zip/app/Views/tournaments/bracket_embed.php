<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
    <h2>Bracket Turnamen: <?= esc($tournament['name']) ?></h2>
    <div style="width: 100%; height: 800px;">
        <iframe src="<?= esc($challonge_url) ?>" style="width: 100%; height: 100%; border: none;"></iframe>
    </div>
    <a href="/tournaments" class="btn btn-secondary mt-3 mb-5">Kembali ke Daftar Turnamen</a>
<?= $this->endSection() ?>
