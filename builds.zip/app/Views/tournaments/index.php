<?= $this->extend('layout') ?>

<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0" style="color: #e43f5a;">🏆 Daftar Turnamen</h2>
    <div>
    <?php if(session()->get('is_admin')): ?>
        <a href="/tournaments/create" class="btn btn-primary me-2">Buat Turnamen Baru</a>
    <?php endif; ?>
    <?php if(session()->get('is_user')): ?>
        <a href="/tournaments/create-user-team" class="btn btn-primary me-2">Buat Tim Baru</a>
        <a href="/tournaments/user-dashboard" class="btn btn-secondary me-2">Dashboard</a>
    <?php endif; ?>
    <?php if(session()->get('is_admin') || session()->get('is_user')): ?>
        <a href="/auth/logout" class="btn btn-danger">Logout</a>
    <?php else: ?>
        <a href="/tournaments/user-login" class="btn btn-success">Login</a>
    <?php endif; ?>
    </div>
</div>

<?php if(session()->has('challonge_client_access_token')): ?>
    <div class="alert alert-info" role="alert">
        Access Token: <?= esc(session()->get('challonge_client_access_token')) ?>
    </div>
<?php else: ?>
    <div class="alert alert-warning" role="alert">
        No Challonge Access Token in session.
    </div>
<?php endif; ?>

<?php if(session()->getFlashdata('success')): ?>
    <div class="alert alert-success" role="alert">
        <?= session()->getFlashdata('success') ?>
    </div>
<?php endif; ?>

<?php if(session()->getFlashdata('warning')): ?>
    <div class="alert alert-warning" role="alert">
        <?= session()->getFlashdata('warning') ?>
    </div>
<?php endif; ?>

<?php if(session()->getFlashdata('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?= session()->getFlashdata('error') ?>
    </div>
<?php endif; ?>

<a href="http://" target="_blank" rel="noopener noreferrer"></a>
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-dark table-hover" style="--bs-table-bg: #162447; --bs-table-hover-bg: #1f4068;">
                <thead>
                    <tr>
                        <th scope="col">Nama Turnamen</th>
                        <th scope="col">Game</th>
                        <th scope="col">Tipe</th>
                        <th scope="col">Tanggal Mulai</th>
                        <?php if(session()->get('is_admin') || session()->get('is_user')): ?>
                        <th scope="col" class="text-center">Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($tournaments)): ?>
                        <?php foreach ($tournaments as $tournament): ?>
                        <tr>
                            <td><?= esc($tournament['name']) ?></td>
                            <td><?= esc($tournament['game_name']) ?></td>
                            <td><?= ucwords(str_replace('_', ' ', esc($tournament['tournament_type']))) ?></td>
                            <td><?= $tournament['start_at'] ? date('d M Y, H:i', strtotime($tournament['start_at'])) : 'N/A' ?></td>
                            <?php if(session()->get('is_admin') || session()->get('is_user')): ?>
                            <td class="text-center">
                                <a href="/tournaments/teams/<?= $tournament['id'] ?>" class="btn btn-info btn-sm">Kelola Tim</a>
                                <a href="/tournaments/manage-team/<?= $tournament['id'] ?>" class="btn btn-secondary btn-sm">Manage Team</a>
                                <a href="/tournaments/edit/<?= $tournament['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="/tournaments/view-bracket/<?= $tournament['id'] ?>" class="btn btn-success btn-sm">Lihat Bracket</a>
                                <?php if(session()->get('is_user')): ?>
                                    <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#registerModal<?= $tournament['id'] ?>">
                                        Daftar
                                    </button>
                                <?php endif; ?>
                                <form action="/tournaments/delete/<?= $tournament['id'] ?>" method="post" class="d-inline">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus turnamen ini? Semua data tim di dalamnya juga akan terhapus.')">Hapus</button>
                                </form>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="<?php if(session()->get('is_admin') || session()->get('is_user')): ?>5<?php else: ?>4<?php endif; ?>" class="text-center py-4">Belum ada turnamen yang dibuat.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php foreach ($tournaments as $tournament): ?>
<!-- Modal -->
<div class="modal fade" id="registerModal<?= $tournament['id'] ?>" tabindex="-1" aria-labelledby="registerModalLabel<?= $tournament['id'] ?>" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" action="/tournaments/register-team/<?= $tournament['id'] ?>">
        <?= csrf_field() ?>
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="registerModalLabel<?= $tournament['id'] ?>">Konfirmasi Pendaftaran</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin mendaftar ke turnamen "<?= esc($tournament['name']) ?>" dengan tim Anda?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary">Daftar</button>
            </div>
        </div>
    </form>
  </div>
</div>
<?php endforeach; ?>
<?= $this->endSection() ?>
