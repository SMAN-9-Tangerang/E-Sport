<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
    <h2>Edit Turnamen</h2>
    <form action="/tournaments/update/<?= $tournament['id'] ?>" method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="_method" value="PUT" />
        <div class="mb-3">
            <label for="name" class="form-label">Nama Turnamen</label>
            <input type="text" name="name" class="form-control" value="<?= esc($tournament['name']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="game_name" class="form-label">Game</label>
            <input type="text" name="game_name" class="form-control" value="<?= esc($tournament['game_name']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Deskripsi</label>
            <textarea name="description" class="form-control"><?= esc($tournament['description']) ?></textarea>
        </div>
        <div class="mb-3">
            <label for="tournament_type" class="form-label">Tipe Turnamen</label>
            <select name="tournament_type" class="form-select">
                <option value="single elimination" <?= $tournament['tournament_type'] == 'single elimination' ? 'selected' : '' ?>>Single Elimination</option>
                <option value="double elimination" <?= $tournament['tournament_type'] == 'double elimination' ? 'selected' : '' ?>>Double Elimination</option>
                <option value="round robin" <?= $tournament['tournament_type'] == 'round robin' ? 'selected' : '' ?>>Round Robin</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="start_at" class="form-label">Tanggal Mulai</label>
            <input type="datetime-local" name="start_at" class="form-control" value="<?= date('Y-m-d\TH:i', strtotime($tournament['start_at'])) ?>">
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
<?= $this->endSection() ?>